

import SwiftUI

struct personalSectionView: View {
    @EnvironmentObject var model: OnboardingViewModel
    
    var title: String
    @Binding var value: Double
    var range : ClosedRange<Double> = 1...100
    var isHeightSection: Bool = false
    
    
    var body: some View {
        VStack(alignment: .leading)
        {
            HStack
            {
                Text(title)
                    .padding(.leading, 15)
                    .font(.custom(.medium , size: 20))
                Spacer()
                Text("\(value, specifier: "%.0f")")
                    .padding(.trailing, 15)
                    .font(.custom(.black, size: 24))
                
            }
            customSlider(value: $value, range: range)
        }
        .frame(height: 100)
        .background(.white)
        .cornerRadius(15)
        .padding(.horizontal, 15)
    }
}

#Preview {
    personalSectionView(title: "Title", value: .constant(100.0), range: 100...250 )
        .environmentObject(OnboardingViewModel())
}
