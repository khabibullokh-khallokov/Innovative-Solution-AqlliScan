import SwiftUI

struct PersonalInfoView: View {
    @EnvironmentObject var model: OnboardingViewModel
    
    var body: some View {
        ScrollView {
            VStack {
                Text("Shahsiyatga oid savollar")
                    .font(.custom(.black, size: 30))
                    .padding(.top)
                
                identitySection
                personalSectionView(title: "Yoshingiz (Age):", value: self.$model.currentAgeValue, range: 0...150)
                    .environmentObject(model)
                
                personalSectionView(title: "Bo’yingiz (sm) (Height in cm):", value: self.$model.curentWeightValue, range: 0...300)
                    .environmentObject(model)
                
                personalSectionView(title: "Og’irligingiz (kg) (Weight in kg):", value: self.$model.currentHeightValue, range: 0...200)
                    .environmentObject(model)
                
                personalSectionView(title: "Faoliyat darajasi (Activity Level):", value: self.$model.currentActivityValue, range: 0...10)
                    .environmentObject(model)
                personalSectionView(title: "Kunlik suv iste'moli?:", value: self.$model.currentWaterConsumption, range: 0...15)
                    .environmentObject(model)
                
                
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.baseLtGray)
    }
    
    var identitySection: some View {
        VStack(alignment: .leading) {
            Text("Jinsingiz nima ?")
            VStack {
                ForEach(0..<model.genders.count, id: \.self) { index in
                    CapsuleListButton(title: model.genders[index], type: self.model.selectedGenderType, index: index, action: {
                        self.model.selectedGenderType = index
                    })
                    
                    if index != model.genders.count-1 {
                        Spacer()
                    }
                }
            }
        }
        .font(.custom(.medium, size: 18))
        .padding(15)
        .background(.white)
        .cornerRadius(15)
        .padding(.horizontal, 15)
        .padding(.bottom, 10)
    }
}

struct PersonalInfoView_Previews: PreviewProvider {
    static var previews: some View {
        PersonalInfoView()
            .environmentObject(OnboardingViewModel())
    }
}
