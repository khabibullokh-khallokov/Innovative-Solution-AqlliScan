import SwiftUI

struct FoodPreferencesView: View {
    @EnvironmentObject var model: OnboardingViewModel
    @State private var buttonPressed = false
    @State private var showTabBar = false
    
    
    var body: some View {
     
            ScrollView {
                nutritionSection
                    .padding(.bottom, 20)
                foodSection
                    .padding(.bottom, 20)
                
                Button(action: {
                                   showTabBar = true
                               }) {
                                   nextButtonShape
                                       .padding(.bottom, 50)
                               }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.baseLtGray)
            .fullScreenCover(isPresented: $showTabBar) {
                        tabBar(viewRouter: ViewRouter())
                    }
        
    }
    
    var nutritionSection: some View {
        VStack {
            Text("Oziq-ovqat imtiyozlari")
                .font(.custom(.black, size: 30))
                .padding(.top)
            VStack(alignment: .leading) {
                Text("Oziqlanish")
                    .font(.custom(.medium, size: 22))
                VStack(alignment: .leading) {
                    ForEach(0..<self.model.nutrition.count, id: \.self) { index in
                        CapsuleListButton(title: self.model.nutrition[index], type: self.model.selectedNutritionType, index: index, action: { self.model.selectedNutritionType = index })
                    }
                }
            }
            .padding(15)
            .frame(maxWidth: .infinity)
            .background(.white)
            .cornerRadius(15)
            .padding(.horizontal, 15)
        }
    }
    
    var foodSection: some View {
        VStack(alignment: .leading) {
            Text("Nimani Yoqtirasiz?")
                .font(.custom(.medium, size: 22))
            
            LazyVGrid(columns: self.model.columns) {
                ForEach(0..<self.model.foodTypes.count, id: \.self) { index in
                    RoundedRectButton(title: self.model.foodTypes[index], icon: self.model.foodIcons[index], type: self.model.selectedFoodType, index: index, action: {
                        self.model.selectedFoodType = index
                    })
                }
            }
        }
        .padding(15)
        .frame(maxWidth: .infinity)
        .background(.white)
        .cornerRadius(15)
        .padding(.horizontal, 15)
    }
    
    var nextButtonShape: some View
    {
        VStack
        {
            Text("Keyingisi")
                .bold().italic()
                .font(.headline)
                .padding()
                .foregroundColor(.black)
                .frame(width: 150, height: 50)
                .background(Color.baseBlue)
                .clipShape(Rectangle())
                .cornerRadius(15)
            
        }
    }
}



struct FoodPreferencesView_Previews: PreviewProvider {
    static var previews: some View {
        FoodPreferencesView()
            .environmentObject(OnboardingViewModel())
    }
}
