import SwiftUI

struct HealthView: View {
    @EnvironmentObject var model: OnboardingViewModel
    
    var body: some View {
        ScrollView {
            VStack {
                Text("Siz haqizdagi ma'lumotlar")
                  .font(.custom(.black, size: 30))
                
                    .padding(.top)
                
                placeSection
                workoutSection
                skillLevelSection
            }
            .navigationBarBackButtonHidden()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.baseLtGray)
    }
    
    var placeSection: some View {
        VStack(alignment: .leading) {
            Text("Qayerda ko'proq vaqtingizni sarflaysiz?")
               .font(.custom(.medium, size: 22))
            
            LazyVGrid(columns: model.columns) {
                ForEach(0..<3) { index in
                    RoundedRectButton(title: self.model.workoutLocationTypes[index], icon: self.model.workoutIcons[index], type: self.model.selectedWorkoutPlaceType, index: index, action: {
                        self.model.selectedWorkoutPlaceType = index
                    })
                }
            }
        }
        .padding(15)
        .background(.white)
        .cornerRadius(15)
        .padding(.horizontal, 15)
        .padding(.bottom, 15)
    }
    
    var workoutSection: some View {
        VStack(alignment: .leading) {
            Text("Sizning maqsadingiz nima ?")
                .font(.custom(.medium, size: 22))
            VStack(alignment: .leading) {
                ForEach(0..<self.model.workoutReason.count, id: \.self) { index in
                    CapsuleListButton(title: model.workoutReason[index], type: self.model.selectedWorkoutReasonType, index: index, action: {
                        self.model.selectedWorkoutReasonType = index
                    })
                }
            }
        }
        .padding(15)
        .frame(maxWidth: .infinity)
        .background(.white)
        .cornerRadius(15)
        .padding(.horizontal, 15)
        .padding(.bottom, 15)
    }
    
    var skillLevelSection: some View {
        VStack(alignment: .leading) {
            Text("Siz Kimsiz?")
                .font(.custom(.medium, size: 22))
            HStack {
                ForEach(0..<self.model.skillLevel.count, id: \.self) { index in
                    CapsuleListButton(title: self.model.skillLevel[index], type: self.model.selectedSkillType, index: index, hasCheckmark: false, action: { self.model.selectedSkillType = index })
                    
                }
                
                Spacer()
            }
        }
        .padding(15)
        .frame(maxWidth: .infinity)
        .background(.white)
        .cornerRadius(15)
        .padding(.horizontal, 15)
    }
}

struct HealthViewView_Previews: PreviewProvider {
    static var previews: some View {
        HealthView()
            .environmentObject(OnboardingViewModel())
    }
}
