
import SwiftUI

enum CustomButtonType: String
{
    case next = "Keyingisi"
    case previous = "Oldingisi"
}


struct CustomNavigationButton_: View {
    var type: CustomButtonType
    var action : () -> Void
    
    var body: some View {
        Button(action: { action() }) {
            Text(type.rawValue)
                .bold()
                .padding(.vertical, 15)
                .padding(.horizontal, 20)
                .foregroundColor(type == .previous ? .baseBlue : .white)
                .background(type == .previous ? Color.white : Color.baseBlue)
        }
        .buttonStyle(.plain)
        .cornerRadius(5)
        .overlay(
            RoundedRectangle(cornerRadius: 5)
                .stroke(Color.baseBlue, lineWidth: 1)
                .opacity(type == .previous ? 1 : 0)
        )
    }
}

#Preview {
    HStack {
        CustomNavigationButton_(type: .previous, action: {})
        CustomNavigationButton_(type: .next, action: {})
    }
}
