import SwiftUI

struct customSlider: View {
    @Binding var value: Double
    var range: ClosedRange<Double> = 1...100
    
    var body: some View {
        VStack(spacing : 0 )
        {
            ZStack(alignment: Alignment(horizontal: .center, vertical: .bottom))
            {
                HStack(spacing: (UIScreen.main.bounds.width - 160) / 55)
                {
                    ForEach(0..<51, id :\.self)
                    {
                        index in
                        Rectangle()
                            .fill(index % 5 == 0 ? Color.black.opacity(0.55) : Color.black.opacity(0.33))
                            .frame(width: 2, height: index % 5 == 0 ? 20 : 12)
                        
                    }
                }
                SliderView(value: $value, sliderRange: range, thumbColor: .baseBlue, minTrackColor: .clear, maxTrackColor: .clear)
                    .padding(.horizontal, 20)
                    .frame(height: 35)
            }
        }
    }
}

#Preview {
    customSlider(value: .constant(100.0), range: 100...300)
}
