import Foundation

class LocalizationManager {
    static let shared = LocalizationManager()
    
    func localizedString(forKey key: String) -> String {
        let language = UserDefaults.standard.string(forKey: "appLanguage") ?? "en"
        let path = Bundle.main.path(forResource: language, ofType: "lproj")
        let bundle = Bundle(path: path!) ?? Bundle.main
        return NSLocalizedString(key, bundle: bundle, comment: "")
       
    }
}
