
import SwiftUI
import OpenFoodFactsSDK

struct ContentView2: View {
    
    @State var barcode: String = ""
    @State var isValidBarcode: Bool = false
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .center, spacing: 10) {
                Spacer()
                Text("Expected format should have 7,8,12 or 13 digits.")
                HStack {
                    TextField("Enter barcode for e.g. 5900102025473", text: $barcode)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .onChange(of: barcode) { newValue in
                            isValidBarcode = newValue.isAValidBarcode()
                            print("\(barcode) and \(isValidBarcode)")
                        }
                    Image(systemName: isValidBarcode ? "checkmark" : "exclamationmark.octagon.fill")
                        .renderingMode(.template).foregroundColor(isValidBarcode ? .green : .red)
                }.padding()
                NavigationLink("Check") {
                    ProductPage(barcode: self.barcode) { uploadedProduct in
                        print(uploadedProduct?.json() ?? "returned product is nil")
                    }
                }.disabled(!isValidBarcode)
                Spacer()
            }
        }
    }
}

#Preview {
    ContentView2()
}
