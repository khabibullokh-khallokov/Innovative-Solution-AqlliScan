import SwiftUI

struct ContentView4: View {
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ScrollView {
            VStack {
                Text("Mahsulotlar")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(Color.blue)
                
                Text("haqida qo'shimcha ma'lumot va maslahatlar")
                    .font(.subheadline)
                    .foregroundColor(Color.gray)
                    .padding(.bottom, 20)
                
                LazyVGrid(columns: columns, spacing: 20) {
                    ProductItem(imageName: "icecream", title: "Muzqaymoq", backgroundColor: Color.pink)
                    ProductItem(imageName: "yogurt", title: "Yo'gurt", backgroundColor: Color.blue.opacity(0.3))
                    ProductItem(imageName: "cookies", title: "Pechenye", backgroundColor: Color.green.opacity(0.3))
                    ProductItem(imageName: "chocolate", title: "Shokolad", backgroundColor: Color.yellow.opacity(0.3))
                    ProductItem(imageName: "milk", title: "Sutli mahsulot", backgroundColor: Color.blue.opacity(0.3))
                    ProductItem(imageName: "cheese", title: "Pishloq", backgroundColor: Color.pink.opacity(0.3))
                    ProductItem(imageName: "children", title: "Bolalar mahsuloti", backgroundColor: Color.green.opacity(0.3))
                    ProductItem(imageName: "yogurt", title: "Fruits", backgroundColor: Color.purple.opacity(0.3))
                }
                .padding(.horizontal)
            }
            .padding()
        }
    }
}

struct ProductItem: View {
    let imageName: String
    let title: String
    let backgroundColor: Color
    
    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(height: 100)
            
            Text(title)
                .font(.headline)
                .foregroundColor(.black)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(backgroundColor)
        .cornerRadius(15)
    }
}

#Preview
{
    ContentView4()
}
