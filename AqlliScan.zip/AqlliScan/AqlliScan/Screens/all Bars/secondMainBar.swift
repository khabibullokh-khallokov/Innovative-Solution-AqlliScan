import SwiftUI

struct ContentView5: View {
    @ObservedObject var viewModel = ECodeViewModel()

    var body: some View {
        NavigationView {
            VStack {
                SearchBar(text: $viewModel.searchText)

                List(viewModel.filteredECodes) { eCode in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(eCode.eCode)
                                .font(.headline)
                            Text(eCode.eName)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        Text(eCode.eStatus)
                            .foregroundColor(eCode.eStatusColor)
                        Image(systemName: eCode.eStatusIcon)
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationBarTitle("Qidirish")
        }
    }
}

struct SearchBar: UIViewRepresentable {
    @Binding var text: String

    class Coordinator: NSObject, UISearchBarDelegate {
        @Binding var text: String

        init(text: Binding<String>) {
            _text = text
        }

        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            text = searchText
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(text: $text)
    }

    func makeUIView(context: Context) -> UISearchBar {
        let searchBar = UISearchBar(frame: .zero)
        searchBar.delegate = context.coordinator
        searchBar.placeholder = "Ecode orqali izlang ..."
        return searchBar
    }

    func updateUIView(_ uiView: UISearchBar, context: Context) {
        uiView.text = text
    }
}

extension ECode {
    var eStatusColor: Color {
        switch eStatus.lowercased() {
        case "haram":
            return .red
        case "shubhali", "musbooh":
            return .yellow
        default:
            return .green
        }
    }

    var eStatusIcon: String {
        switch eStatus.lowercased() {
        case "haram":
            return "nosign"
        case "shubhali", "musbooh":
            return "exclamationmark.circle"
        default:
            return "checkmark.circle"
        }
    }
}

      
#Preview
{ContentView5()}
