
import SwiftUI

struct ECode: Identifiable, Codable {
    var id: String { eCode }
    let eCode: String
    let eName: String
    let eDesc: String
    let eStatus: String
    let eClarification: String
}
