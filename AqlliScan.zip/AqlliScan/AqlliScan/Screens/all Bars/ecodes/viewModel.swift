import SwiftUI
import Combine

class ECodeViewModel: ObservableObject {
    @Published var eCodes: [ECode] = []
    @Published var filteredECodes: [ECode] = []
    @Published var searchText: String = ""

    private var cancellables = Set<AnyCancellable>()

    init() {
        loadJSON()

        $searchText
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .sink { [weak self] searchText in
                guard let self = self else { return }
                if searchText.isEmpty {
                    self.filteredECodes = self.eCodes
                } else {
                    self.filteredECodes = self.eCodes.filter { $0.eCode.localizedCaseInsensitiveContains(searchText) }
                }
            }
            .store(in: &cancellables)
    }

    func loadJSON() {
        if let url = Bundle.main.url(forResource: "e-codes", withExtension: "json") {
            if let data = try? Data(contentsOf: url) {
                let decoder = JSONDecoder()
                if let jsonEcodes = try? decoder.decode([ECode].self, from: data) {
                    self.eCodes = jsonEcodes
                    self.filteredECodes = jsonEcodes
                }
            }
        }
    }
}
