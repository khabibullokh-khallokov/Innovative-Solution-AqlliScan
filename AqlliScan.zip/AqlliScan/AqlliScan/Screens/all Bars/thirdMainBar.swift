
import SwiftUI

struct ProfileView: View {
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Profil")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 40)
                
                ProfileHeaderView()
                    .padding(.horizontal)
                
                ProfileMenu()
                    .padding(.horizontal)
                
                Spacer()
            }
            .background(Color(.systemGray6))
            .navigationBarHidden(true)
        }
    }
}

struct ProfileHeaderView: View {
    var body: some View {
        HStack {
            Image(systemName: "person.crop.circle.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.gray)
            
            VStack(alignment: .leading) {
                Text("Ism Familiya")
                    .font(.headline)
                Text("yosh")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            .padding(.leading, 10)
            
            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 5)
    }
}

struct ProfileMenu: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Dastur")
                .font(.headline)
                .padding(.bottom, 10)
                .padding(.leading, 16)
            
            MenuRow(title: "Parhez")
            Divider()
            MenuRow(title: "Mening Kasalliklarim")
            Divider()
            MenuRow(title: "Qo'shimcha")
            Divider()
            MenuRow(title: "PRO Versiyaga o’tish", isPro: true)
        }
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 5)
    }
}

struct MenuRow: View {
    var title: String
    var isPro: Bool = false
    
    var body: some View {
        HStack {
            Text(title)
                .font(.body)
            
            Spacer()
            
            if isPro {
                Text("PRO")
                    .font(.caption)
                    .fontWeight(.bold)
                    .padding(4)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(5)
            }
            
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
        .padding()
    }
}


#Preview {
    ProfileView()
}
