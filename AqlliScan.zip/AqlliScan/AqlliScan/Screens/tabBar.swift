
import SwiftUI

struct tabBar: View {
    
    @StateObject var viewRouter: ViewRouter
    
    @State var showPopUp = false
   
    
    var body: some View {
        NavigationView{
            GeometryReader { geometry in
                VStack {
                    Spacer()
                    switch viewRouter.currentPage {
                    case .home:
                        ContentView4()
                       
                    case .liked:
                        //secondMainBar()
                        ContentView5()
                    case .records:
                        fourthMainBar()
                    case .user:
                        ProfileView()
                    }
                    Spacer()
                    ZStack {
                        if showPopUp {
                            PlusMenu(widthAndHeight: geometry.size.width/7)
                                .offset(y: -geometry.size.height/6)
                        }
                        HStack {
                            TabBarIcon(viewRouter: viewRouter, assignedPage: .home, width: geometry.size.width/5, height: geometry.size.height/28, systemIconName: "homekit", tabName: "Asosiy")
                            TabBarIcon(viewRouter: viewRouter, assignedPage: .liked, width: geometry.size.width/5, height: geometry.size.height/28, systemIconName: "cart.fill.badge.questionmark", tabName: "Maslahatlar")
                            ZStack {
                                Circle()
                                    .foregroundColor(.black)
                                    .frame(width: geometry.size.width/7, height: geometry.size.width/7)
                                    .shadow(radius: 4)
                                
                                
                                Image(systemName: "camera")
                                //.resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geometry.size.width/7-6, height: geometry.size.width/7-6)
                                    .foregroundColor(Color.white)
                                    .rotationEffect(Angle(degrees: showPopUp ? 90 : 0))
                            }
                            .offset(y: -geometry.size.height/8/2)
                            .onTapGesture {
                                withAnimation {
                                    showPopUp.toggle()
                                }
                            }
                           
                            TabBarIcon(viewRouter: viewRouter, assignedPage: .records, width: geometry.size.width/5, height: geometry.size.height/28, systemIconName: "heart", tabName: "Saqlanganlar")
                            TabBarIcon(viewRouter: viewRouter, assignedPage: .user, width: geometry.size.width/5, height: geometry.size.height/28, systemIconName: "person.crop.circle", tabName: "Profil")
                        }
                        .frame(width: geometry.size.width, height: geometry.size.height/8)
                        .background(Color.baseBlue.shadow(radius: 2))
                    }
                }
                .edgesIgnoringSafeArea(.bottom)
            }
        }
    }
}


struct PlusMenu: View {
    
    let widthAndHeight: CGFloat
    
    var body: some View {
        HStack(spacing: 50) {
            NavigationLink(destination: ContentView3())
            {
                ZStack {
                    Circle()
                        .foregroundColor(Color.baseBlue)
                        .frame(width: widthAndHeight, height: widthAndHeight)
                    Image(systemName: "barcode")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(15)
                        .frame(width: widthAndHeight, height: widthAndHeight)
                        .foregroundColor(.white)
                }
            }
            
            NavigationLink(destination: StartupView())
            {
                ZStack {
                    Circle()
                        .foregroundColor(Color.baseBlue)
                        .frame(width: widthAndHeight, height: widthAndHeight)
                    Image(systemName: "pencil")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(15)
                        .frame(width: widthAndHeight, height: widthAndHeight)
                        .foregroundColor(.white)
                }
            }
        }
        .transition(.scale)
    }
}

struct TabBarIcon: View {
    
    @StateObject var viewRouter: ViewRouter
    let assignedPage: Page
    
    let width, height: CGFloat
    let systemIconName, tabName: String
    
    var body: some View {
        VStack {
            Image(systemName: systemIconName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: width, height: height)
                .padding(.top, 10)
            Text(tabName)
                .font(.footnote)
            Spacer()
        }
        .padding(.horizontal, -4)
        .onTapGesture {
            viewRouter.currentPage = assignedPage
        }
        .foregroundColor(viewRouter.currentPage == assignedPage ? Color.baseLtGray : .black)
    }
}

#Preview
{
    tabBar(viewRouter: ViewRouter())
}
