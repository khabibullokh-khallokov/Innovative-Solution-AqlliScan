
import SwiftUI

import Lottie

struct StartupView: View {
    var body: some View {
        NavigationView
        {
            VStack {
                Spacer()
                
                VStack {
                    LottieView(filename: "scanner2", width: 100, height: 600)
                        .frame(width: 100, height: 100)
                        
                               
                               Text("AqlliScan")
                                   .font(.largeTitle)
                                   .fontWeight(.bold)
                                   .foregroundColor(.baseBlue)
                               
                               Text("Shaxsiylashtirilgan sog‘lom ovqatlanish va kosmetika mahsulotlarini tahlil qilish")
                                   .bold()
                                   .font(.subheadline)
                                   .foregroundColor(Color.gray)
                                   .multilineTextAlignment(.center)
                                   .padding(.horizontal)
                }
                
                Spacer()
                
              
                    NavigationLink(destination: SignInUp())
                {
                    Text("Boshlash")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(.baseBlue)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }
                //.padding(.bottom, 50)
                // Login Prompt
                HStack {
                    Text("Oldin registratsiyadan o'tganmisiz")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    Button(action: {
                        // Text("Login button is pressed")
                        
                    }) {
                        Text("Log in")
                            .font(.subheadline)
                            .foregroundColor(.baseBlue)
                    }
                    
                }
                .padding(.bottom, 50)
            }
            .background(Color.white)
            .edgesIgnoringSafeArea(.all)
        }
    }
}

struct LottieView: UIViewRepresentable {
    var filename: String
    var width: CGFloat
    var height: CGFloat
    
    func makeUIView(context: Context) -> some UIView {
        let view = UIView(frame: .zero)
        
        let animationView = LottieAnimationView(name: filename)
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .loop
        animationView.play()
        
        animationView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(animationView)
        
        NSLayoutConstraint.activate([
            animationView.widthAnchor.constraint(equalToConstant: width),
            animationView.heightAnchor.constraint(equalToConstant: height),
            animationView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            animationView.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
        
        return view
    }
    
    func updateUIView(_ uiView: UIViewType, context: Context) {}
}


#Preview {
    StartupView()
}
