# AqlliScan
 We are Creating an application that scans food item barcodes, classifies ingredients, and provides comprehensive information and recommendations for people with health concerns.
