import SwiftUI

struct ContentView: View {
    @StateObject var model = OnboardingViewModel()
    @State private var currentPage: Int = 0
    
    var body: some View {
        VStack {
            tabView
            navBar
        }
        .navigationBarBackButtonHidden()
        .background(Color.baseLtGray.edgesIgnoringSafeArea(.all))
    }
    
    var tabView: some View {
        TabView(selection: $currentPage) {
            HealthView()
                .environmentObject(model)
                .tag(0)
            PersonalInfoView()
                .environmentObject(model)
                .tag(1)
            FoodPreferencesView()
                .environmentObject(model)
                .tag(2)
            
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
    }
    
    var navBar: some View {
        HStack {
            HStack {
                ForEach(0..<3, id: \.self) { index in
                    DotView(index: index, currentPage: self.$currentPage)
                }
            }
            
            Spacer()
            
            HStack {
                CustomNavigationButton_(type: .previous, action: {
                    self.currentPage -= 1
                })
                .opacity(self.currentPage > 0 ? 1 : 0)
                
                CustomNavigationButton_ (type: .next, action: {
                    self.currentPage += 1
                })
                .opacity(self.currentPage == 2 ? 0 : 1)
            }
        }
        .padding(15)
        .background(.white)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
