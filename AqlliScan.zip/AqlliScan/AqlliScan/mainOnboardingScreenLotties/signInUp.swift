
import SwiftUI
import Firebase
import FirebaseAuth

struct SignInUp: View {
    
    enum SignInState {
        case signUp, login
    }
    
    @State private var password = ""
    @State private var email = ""
    @State private var userIsLoggedIn = false
    @State private var signInState: SignInState = .signUp
    
    var body: some View {
        if userIsLoggedIn {
           ContentView()
        } else {
            content
            
        }
    }
    
    var content: some View {
        ZStack {
            Color.black
            .ignoresSafeArea()
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .foregroundStyle(.baseBlue)
                .frame(width: 1000, height: 400)
                .rotationEffect(.degrees(135))
                .offset(y: -350)
            
            VStack(spacing: 20) {
                Text(signInState == .signUp ? "Registratsiya" : "Kirish")
                    .foregroundColor(.white)
                    .font(.system(size: 40, weight: .bold, design: .rounded))
                    .offset(x: -50, y: -100 )
                TextField("Emailni kiriting", text: $email )
                    .foregroundColor(.black)
                   // .bold()
                    .textFieldStyle(.roundedBorder)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(email.isEmpty ? Color.white.opacity(1) : .clear, lineWidth: 1)
                    )
                    .padding(.horizontal)
                
                SecureField("Parolingizni kiriting", text: $password)
                    .foregroundColor(.black)
                 //   .bold()
                    .textFieldStyle(.roundedBorder)
                    .padding()
                
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(password.isEmpty ? Color.white.opacity(1) : .clear, lineWidth: 1)
                    )
                    .padding(.horizontal)
                
                Button(action: {
                    if signInState == .signUp {
                       register()
                    } else {
                      login()
                    }
                }) {
                    Text(signInState == .signUp ? "Registratsiya" : "Kirish")
                        .bold()
                        .frame(width: 200, height: 40)
                        .foregroundColor(.white)
                        .background(RoundedRectangle(cornerRadius: 10, style: .continuous)
                            .fill(.linearGradient(colors: [.blue, .green], startPoint: .top, endPoint: .bottomLeading)))
                }
                .padding(.top)
                .offset(y: 110)
                
                Button(action: {
                    signInState = signInState == .signUp ? .login : .signUp
                }) {
                    Text(signInState == .signUp ? "Akkauntingiz bormi? Kirish!" : "Registratsiyadan o'tmaganmisiz? Yaratish!")
                        .bold()
                        .foregroundColor(.white)
                }
                .padding(.top)
                .offset(y: 110)
            }
            .frame(width: 350)
        }.navigationBarBackButtonHidden()
        
    }
        
    
    func register() {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                print(error.localizedDescription)

            } else {
                // Registration successful, set userIsLoggedIn to true
                self.userIsLoggedIn = true
            }
        }
    }

    func login() {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                print(error.localizedDescription)
            } else {
                // Login successful, set userIsLoggedIn to true
                self.userIsLoggedIn = true
            }
        }
    }
}
#Preview {
    SignInUp()
}


extension View
{
    func placeholder<Content: View>(
        when shouldShow : Bool,
        alignment : Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View
    {
        ZStack(alignment: alignment){
            placeholder().opacity(shouldShow ? 1 : 0)
            self
            
        }
    }
}

