import Foundation

enum customFont: String {
    case black = "BarlowSemiCondensed-Black"
    case bold = "BarlowSemiCondensed-Bold"
    case medium = "BarlowSemiCondensed-Medium"
}
