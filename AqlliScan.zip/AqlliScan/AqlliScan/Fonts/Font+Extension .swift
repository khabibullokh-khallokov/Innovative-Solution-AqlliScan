
import SwiftUI

extension Font {
    static func custom(_ font: customFont, size: CGFloat) -> SwiftUI.Font {
        SwiftUI.Font.custom(font.rawValue, size: size)
    }
}
